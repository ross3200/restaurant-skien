# Grenland Kjøkken – restaurantplan

Norsk oppstartspakke og interaktiv planportal. Arbeidsnavn, ikke registrert firma.

Åpne index.html i nettleseren. Krever ingen installasjon, konto eller eksterne biblioteker.

## Innhold

- index.html: plan, lånekalkulator og lokal sjekkliste
- docs/forretningsplan.md: norsk gjennomgang, budsjett, regler, finansiering og lokaler
- docs/driftsmaler.md: arbeidsmaler som må tilpasses
- .github/workflows/pages.yml: manuell publisering på GitHub Pages

## GitHub

Opprett et privat repository og last opp innholdet i denne mappen. Ingen opplasting er gjort av assistenten. Portalen kan brukes lokalt uten publisering. For offentlig GitHub Pages: gjennomgå først innholdet, velg GitHub Actions under Settings → Pages, og kjør Deploy Pages fra Actions. Private repos krever en GitHub-plan som støtter Pages, og selve Pages-nettstedet kan være offentlig tilgjengelig. Ikke legg persondata, bankpapirer eller reelle personalregistre her.

## Begrensninger

Ingen kundeordre, betaling, reservasjon, regnskap, lovlig personalliste eller automatisk regeloppdatering. Sjekklisten lagres bare lokalt i nettleseren og kan gå tapt. Budsjettene er antakelser. Kilder kontrollert 25.10.2026; avklar konkrete krav før åpning.
