# Driftsmaler — tilpass før bruk

## Ansvar og opplæring

| Område | Ansvarlig | Stedfortreder | Opplært dato | Dokumentasjon |
|---|---|---|---|---|
| Mattrygghet | | | | |
| HMS/brann | | | | |
| Lønn og kasse | | | | |

## Temperatur og mottak

Dato/tid · vare/utstyr · batch/leverandør · målt temperatur · fastsatt grense fra fareanalyse · avvik/tiltak · signatur.

## Renholdsplan

Område/utstyr · metode · middel/dosering etter leverandøranvisning · frekvens · ansvarlig · utført dato · kontroll.

## Avvikslogg

Dato · hendelse · berørt mat/utstyr · umiddelbart tiltak · ansvarlig · frist · årsak · forebygging · lukket/kontrollert.

## Oppskriftskort

Rett · porsjonsstørrelse · ingredienser/leverandør · allergener · risiko for krysskontakt · tilberedning og oppbevaring · kostnad eks. mva · salgspris/mva · versjonsdato.

## Ukentlig økonomi

Uke · salg inkl./ekskl. mva · antall kjøp · råvarer · svinn · lønnstimer · faste betalinger · renter/avdrag · bankbeholdning · kommende avgifter · tiltak.

## Visningsnotat

Adresse · kontakt · ledighet bekreftet dato · leie/kjøp · felleskostnader · depositum · godkjent bruk dokumentert · tekniske funn · utstyrseierskap · investeringer · avtalevilkår · åpne spørsmål.

## Bankmappe

Eiere og CV · egenkapitalbevis · markedstest · tilbud · betinget lokaleavtale · tillatelsesstatus · 12 måneder resultat og likviditet · sikkerhet og kausjonsramme.

Ikke før fødselsnumre eller personaldata i dette repoet. Disse malene erstatter ikke lovpålagt personalliste, arbeidsavtale eller en virksomhetstilpasset fareanalyse.
